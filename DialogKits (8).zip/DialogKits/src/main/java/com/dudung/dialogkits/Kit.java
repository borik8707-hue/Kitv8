package com.dudung.dialogkits;

import org.bukkit.inventory.ItemStack;

import java.util.List;

public record Kit(String id, String label, String description, Category category,
                  boolean permissionRequired, String permission,
                  boolean oneTime, long cooldown, List<String> commands, List<ItemStack> items) {

    public enum Category {
        BASIC, PREMIUM;

        public static Category from(String s) {
            return "premium".equalsIgnoreCase(s) ? PREMIUM : BASIC;
        }

        public String key() {
            return name().toLowerCase();
        }
    }

    /** Permission node yang dipakai kit ini. */
    public String node() {
        return permission == null || permission.isBlank() ? "dialogkits.kit." + id : permission;
    }

    public Kit withItems(List<ItemStack> newItems) {
        return new Kit(id, label, description, category, permissionRequired, permission,
                oneTime, cooldown, commands, newItems);
    }
}
