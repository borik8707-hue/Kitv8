package com.dudung.dialogkits;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class DialogKits extends JavaPlugin implements Listener {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    /** {diamond} / {Oak_Log} -> icon. Prefix opsional: {item:nama} atau {block:nama}. */
    private static final java.util.regex.Pattern ITEM =
            java.util.regex.Pattern.compile("\\{(?:(item|block):)?([A-Za-z0-9_]+)\\}", java.util.regex.Pattern.CASE_INSENSITIVE);
    private KitManager kitManager;
    private KitMenu menu;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        kitManager = new KitManager(this);
        kitManager.load();
        kitManager.start();
        menu = new KitMenu(this);

        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(new EditorListener(this), this);

        PluginCommand cmd = getCommand("kit");
        if (cmd != null) {
            KitCommand handler = new KitCommand(this);
            cmd.setExecutor(handler);
            cmd.setTabCompleter(handler);
        }
    }

    @Override
    public void onDisable() {
        if (menu != null) menu.shutdown();
        if (kitManager != null) kitManager.stop();
    }

    public void reloadAll() {
        reloadConfig();
        kitManager.load();
    }

    public KitManager kits() { return kitManager; }

    public KitMenu menu() { return menu; }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        kitManager.clearDraft(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (p.hasPlayedBefore()) return;
        String name = getConfig().getString("claim.first-join-kit", "");
        if (name == null || name.isBlank()) return;
        Bukkit.getScheduler().runTaskLater(this, () -> {
            Kit kit = kitManager.get(name);
            if (kit != null && p.isOnline()) claim(p, kit);
        }, 40L);
    }

    /** Claim kit + efek (pesan, sound, title, actionbar, command). */
    public void claim(Player p, Kit kit) {
        KitManager.Result r = kitManager.claim(p, kit, false);
        switch (r) {
            case OK -> onClaimed(p, kit);
            case NO_PERMISSION -> p.sendMessage(msg("no-permission"));
            case ONE_TIME -> p.sendMessage(msg("one-time"));
            case FULL -> p.sendMessage(msg("inventory-full-deny"));
            case COOLDOWN -> p.sendMessage(msg("cooldown", "time",
                    KitManager.formatTime(kitManager.remaining(p, kit))));
        }
    }

    private void onClaimed(Player p, Kit kit) {
        FileConfiguration c = getConfig();
        if (c.getBoolean("claim.message", true)) p.sendMessage(msg("claimed", "kit", kit.id()));

        if (c.getBoolean("claim.sound.enabled", true)) {
            try {
                p.playSound(Sound.sound(Key.key(c.getString("claim.sound.name", "entity.player.levelup")),
                        Sound.Source.MASTER,
                        (float) c.getDouble("claim.sound.volume", 1.0),
                        (float) c.getDouble("claim.sound.pitch", 1.0)));
            } catch (Exception ignored) { }
        }
        if (c.getBoolean("claim.actionbar.enabled", false)) {
            p.sendActionBar(mm(c.getString("claim.actionbar.text", "").replace("{kit}", kit.id())));
        }
        if (c.getBoolean("claim.title.enabled", false)) {
            p.showTitle(Title.title(
                    mm(c.getString("claim.title.title", "").replace("{kit}", kit.id())),
                    mm(c.getString("claim.title.subtitle", "").replace("{kit}", kit.id()))));
        }
        for (String cmd : kit.commands()) {
            if (cmd == null || cmd.isBlank()) continue;
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("{player}", p.getName()));
        }
    }

    /** Pesan dari config + placeholder + prefix. */
    public Component msg(String key, String... pairs) {
        String raw = getConfig().getString("messages." + key, key);
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            raw = raw.replace("{" + pairs[i] + "}", pairs[i + 1]);
        }
        return mm(getConfig().getString("messages.prefix", "") + raw);
    }

    /** Teks -> Component. Support {item}, &a &b ... &l &r, &#RRGGBB, dan MiniMessage. */
    public Component mm(String raw) {
        return MM.deserialize(legacy(icons(raw == null ? "" : raw)));
    }

    // Sprite item ada di atlas "items" (client 1.21.11+/26.x) atau "blocks" (client 1.21.9-1.21.10); blok selalu di "blocks".
    private static final java.util.Set<String> WOODS = java.util.Set.of(
            "oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "mangrove",
            "cherry", "pale_oak", "bamboo", "crimson", "warped");

    /** Blok yang punya sprite item sendiri (item/NAMA), bukan texture blok. */
    private static final java.util.Set<String> ITEM_SPRITE_BLOCKS = java.util.Set.of(
            "brewing_stand", "cauldron", "hopper", "repeater", "comparator", "campfire",
            "soul_campfire", "bell", "flower_pot", "lantern", "soul_lantern", "chain",
            "candle", "sugar_cane");

    /** Nama texture blok yang beda dari nama item-nya. */
    private static final java.util.Map<String, String> BLOCK_TEX = java.util.Map.ofEntries(
            java.util.Map.entry("crafting_table", "crafting_table_front"),
            java.util.Map.entry("furnace", "furnace_front"),
            java.util.Map.entry("blast_furnace", "blast_furnace_front"),
            java.util.Map.entry("smoker", "smoker_front"),
            java.util.Map.entry("grass_block", "grass_block_side"),
            java.util.Map.entry("tnt", "tnt_side"),
            java.util.Map.entry("barrel", "barrel_side"),
            java.util.Map.entry("pumpkin", "pumpkin_side"),
            java.util.Map.entry("melon", "melon_side"),
            java.util.Map.entry("hay_block", "hay_block_side"),
            java.util.Map.entry("dispenser", "dispenser_front"),
            java.util.Map.entry("dropper", "dropper_front"),
            java.util.Map.entry("observer", "observer_front"),
            java.util.Map.entry("piston", "piston_side"),
            java.util.Map.entry("sticky_piston", "piston_side"),
            java.util.Map.entry("loom", "loom_front"),
            java.util.Map.entry("cartography_table", "cartography_table_side1"),
            java.util.Map.entry("fletching_table", "fletching_table_front"),
            java.util.Map.entry("smithing_table", "smithing_table_front"),
            java.util.Map.entry("enchanting_table", "enchanting_table_side"),
            java.util.Map.entry("jukebox", "jukebox_side"),
            java.util.Map.entry("cake", "cake_side"),
            java.util.Map.entry("target", "target_side"),
            java.util.Map.entry("lectern", "lectern_front"),
            java.util.Map.entry("composter", "composter_side"),
            java.util.Map.entry("quartz_block", "quartz_block_side"),
            java.util.Map.entry("bookshelf", "bookshelf"),
            java.util.Map.entry("chiseled_bookshelf", "chiseled_bookshelf_occupied"),
            java.util.Map.entry("podzol", "podzol_side"),
            java.util.Map.entry("mycelium", "mycelium_side"),
            java.util.Map.entry("dirt_path", "dirt_path_side"),
            java.util.Map.entry("bee_nest", "bee_nest_side"),
            java.util.Map.entry("beehive", "beehive_side"),
            java.util.Map.entry("respawn_anchor", "respawn_anchor_side0"));

    /** Sprite item yang namanya beda dari nama item-nya. */
    private static final java.util.Map<String, String> ITEM_TEX = java.util.Map.of(
            "compass", "compass_00",
            "recovery_compass", "recovery_compass_00",
            "clock", "clock_00",
            "crossbow", "crossbow_standby");

    private static String blockTexture(String n) {
        String m = BLOCK_TEX.get(n);
        if (m != null) return m;
        for (String suf : new String[]{"_fence_gate", "_stairs", "_slab", "_fence", "_wall", "_button", "_pressure_plate", "_pane"}) {
            if (n.endsWith(suf)) {
                String base = n.substring(0, n.length() - suf.length());
                if (WOODS.contains(base)) return base + "_planks";
                if (base.endsWith("brick") || base.endsWith("tile")) return base + "s";
                return base;
            }
        }
        return n;
    }

    private static boolean isItemSpriteBlock(String n) {
        return ITEM_SPRITE_BLOCKS.contains(n) || n.endsWith("_door") || n.endsWith("_sign")
                || n.endsWith("_hanging_sign") || n.endsWith("_bed") || n.endsWith("_banner")
                || n.endsWith("_candle");
    }

    private static String sprite(String atlas, String path) {
        return "<sprite:" + atlas + ":" + path + ">";
    }

    /** {nama_item} -> tag sprite. Huruf besar/kecil bebas. {item:x} / {block:x} buat maksa. */
    private String icons(String raw) {
        if (raw.indexOf('{') < 0) return raw;
        String itemAtlas = getConfig().getString("icons.item-atlas", "items");
        String blockAtlas = getConfig().getString("icons.block-atlas", "blocks");
        return ITEM.matcher(raw).replaceAll(m -> {
            String kind = m.group(1) == null ? null : m.group(1).toLowerCase();
            String name = m.group(2).toLowerCase();

            if (kind == null) {
                // override manual dari config: "item:nama", "block:nama", atau nama texture blok
                String custom = getConfig().getString("icons.overrides." + name);
                if (custom != null && !custom.isBlank()) {
                    String c = custom.trim().toLowerCase();
                    if (c.startsWith("item:")) return sprite(itemAtlas, "item/" + c.substring(5));
                    if (c.startsWith("block:")) return sprite(blockAtlas, "block/" + c.substring(6));
                    return sprite(blockAtlas, "block/" + c);
                }

                Material mat = Material.matchMaterial(name);
                if (mat == null || !mat.isItem()) return m.group();

                if (mat.isBlock() && !isItemSpriteBlock(name)) {
                    return sprite(blockAtlas, "block/" + blockTexture(name));
                }
                return sprite(itemAtlas, "item/" + ITEM_TEX.getOrDefault(name, name));
            }
            return kind.equals("block")
                    ? sprite(blockAtlas, "block/" + name)
                    : sprite(itemAtlas, "item/" + name);
        });
    }

    private static String legacy(String s) {
        if (s.indexOf('&') < 0) return s;
        StringBuilder sb = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '&' && i + 1 < s.length()) {
                char n = Character.toLowerCase(s.charAt(i + 1));
                if (n == '#' && i + 8 <= s.length() && isHex(s, i + 2, i + 8)) {
                    sb.append("<reset><#").append(s, i + 2, i + 8).append('>');
                    i += 7;
                    continue;
                }
                String tag = tag(n);
                if (tag != null) {
                    sb.append(tag);
                    i++;
                    continue;
                }
            }
            sb.append(ch);
        }
        return sb.toString();
    }

    private static boolean isHex(String s, int from, int to) {
        for (int i = from; i < to; i++) {
            if (Character.digit(s.charAt(i), 16) < 0) return false;
        }
        return true;
    }

    private static String tag(char c) {
        return switch (c) {
            case '0' -> "<reset><black>";
            case '1' -> "<reset><dark_blue>";
            case '2' -> "<reset><dark_green>";
            case '3' -> "<reset><dark_aqua>";
            case '4' -> "<reset><dark_red>";
            case '5' -> "<reset><dark_purple>";
            case '6' -> "<reset><gold>";
            case '7' -> "<reset><gray>";
            case '8' -> "<reset><dark_gray>";
            case '9' -> "<reset><blue>";
            case 'a' -> "<reset><green>";
            case 'b' -> "<reset><aqua>";
            case 'c' -> "<reset><red>";
            case 'd' -> "<reset><light_purple>";
            case 'e' -> "<reset><yellow>";
            case 'f' -> "<reset><white>";
            case 'k' -> "<obfuscated>";
            case 'l' -> "<bold>";
            case 'm' -> "<strikethrough>";
            case 'n' -> "<underlined>";
            case 'o' -> "<italic>";
            case 'r' -> "<reset>";
            default -> null;
        };
    }
}
