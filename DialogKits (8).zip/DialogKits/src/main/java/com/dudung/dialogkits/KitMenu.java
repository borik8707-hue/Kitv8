package com.dudung.dialogkits;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.dialog.DialogResponseView;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import io.papermc.paper.registry.data.dialog.input.SingleOptionDialogInput;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.JoinConfiguration;
import net.kyori.adventure.text.event.ClickCallback;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public final class KitMenu {

    private final DialogKits plugin;
    private final Map<UUID, BukkitTask> live = new HashMap<>();

    public KitMenu(DialogKits plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------ helpers

    private FileConfiguration cfg() { return plugin.getConfig(); }

    private int width() { return cfg().getInt("menu.button-width", 200); }

    private int columns() { return Math.max(1, cfg().getInt("menu.columns", 1)); }

    private ClickCallback.Options opts() {
        return ClickCallback.Options.builder()
                .uses(ClickCallback.UNLIMITED_USES)
                .lifetime(ClickCallback.DEFAULT_LIFETIME)
                .build();
    }

    private DialogAction act(Consumer<Player> run) {
        return DialogAction.customClick((view, audience) -> {
            if (audience instanceof Player p) {
                stopLive(p);
                run.accept(p);
            }
        }, opts());
    }

    private DialogAction actView(BiConsumer<Player, DialogResponseView> run) {
        return DialogAction.customClick((view, audience) -> {
            if (audience instanceof Player p) {
                stopLive(p);
                run.accept(p, view);
            }
        }, opts());
    }

    private ActionButton button(String label, Component tooltip, DialogAction action) {
        ActionButton.Builder b = ActionButton.builder(plugin.mm(label)).width(width());
        if (tooltip != null) b.tooltip(tooltip);
        if (action != null) b.action(action);
        return b.build();
    }

    private Component tip(String raw) {
        return raw == null || raw.isBlank() ? null : plugin.mm(raw);
    }

    private ActionButton closeButton() {
        return button(cfg().getString("menu.close-button", "<red>Close"), null, null);
    }

    private ActionButton backButton() {
        return button(cfg().getString("menu.back-button", "<yellow>Back"), null, act(this::openMain));
    }

    // ------------------------------------------------------------ menu utama

    public void openMain(Player player) {
        stopLive(player);
        FileConfiguration c = cfg();
        List<ActionButton> buttons = new ArrayList<>();
        buttons.add(button(c.getString("menu.basic-button", "Basic Kits"),
                tip(c.getString("menu.basic-tooltip", "")),
                act(p -> openCategory(p, Kit.Category.BASIC))));
        buttons.add(button(c.getString("menu.premium-button", "Premium Kits"),
                tip(c.getString("menu.premium-tooltip", "")),
                act(p -> openCategory(p, Kit.Category.PREMIUM))));

        Dialog dialog = Dialog.create(b -> b.empty()
                .base(DialogBase.builder(plugin.mm(c.getString("menu.title", "Kits")))
                        .canCloseWithEscape(true)
                        .build())
                .type(DialogType.multiAction(buttons, closeButton(), columns())));
        player.showDialog(dialog);
    }

    // ------------------------------------------------------------ list kit (basic / premium)

    public void openCategory(Player player, Kit.Category cat) {
        stopLive(player);
        boolean running = cfg().getBoolean("menu.live-cooldown", true) && hasCooldown(player, cat);
        Dialog dialog = buildCategory(player, cat, running);
        player.showDialog(dialog);
        if (running) startLive(player, cat);
    }

    private boolean hasCooldown(Player p, Kit.Category cat) {
        KitManager km = plugin.kits();
        for (Kit k : km.in(cat)) {
            if (km.hasAccess(p, k) && km.remaining(p, k) > 0) return true;
        }
        return false;
    }

    /** Dialog itu statis, jadi buat timer jalan menu dikirim ulang tiap beberapa tick selama masih ada cooldown. */
    private void startLive(Player player, Kit.Category cat) {
        long period = Math.max(5L, cfg().getLong("menu.live-refresh-ticks", 20L));
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline() || player.isDead()) {
                stopLive(player);
                return;
            }
            boolean still = hasCooldown(player, cat);
            player.showDialog(buildCategory(player, cat, still));
            if (!still) stopLive(player);
        }, period, period);
        live.put(player.getUniqueId(), task);
    }

    private void stopLive(Player p) {
        BukkitTask t = live.remove(p.getUniqueId());
        if (t != null) t.cancel();
    }

    public void shutdown() {
        live.values().forEach(BukkitTask::cancel);
        live.clear();
    }

    private Dialog buildCategory(Player player, Kit.Category cat, boolean lockEscape) {
        FileConfiguration c = cfg();
        KitManager km = plugin.kits();
        String title = cat == Kit.Category.BASIC
                ? c.getString("menu.basic-title", "Basic Kits")
                : c.getString("menu.premium-title", "Premium Kits");
        String suffix = c.getString("menu.button-suffix", "");

        List<ActionButton> buttons = new ArrayList<>();
        for (Kit kit : km.in(cat)) {
            List<Component> tip = new ArrayList<>();
            if (!kit.description().isBlank()) tip.add(plugin.mm(kit.description()));
            tip.add(statusLine(player, kit));

            String label = kit.label();
            if (!suffix.isBlank()) label += suffix.replace("{status}", shortStatus(player, kit));

            buttons.add(button(label,
                    Component.join(JoinConfiguration.newlines(), tip),
                    act(p -> plugin.claim(p, kit))));
        }

        if (buttons.isEmpty()) {
            return Dialog.create(b -> b.empty()
                    .base(DialogBase.builder(plugin.mm(title))
                            .canCloseWithEscape(true)
                            .body(List.of(DialogBody.plainMessage(
                                    plugin.mm(c.getString("messages.no-kits", "Belum ada kit")))))
                            .build())
                    .type(DialogType.notice(backButton())));
        }

        return Dialog.create(b -> b.empty()
                .base(DialogBase.builder(plugin.mm(title))
                        .canCloseWithEscape(!lockEscape)
                        .build())
                .type(DialogType.multiAction(buttons, backButton(), columns())));
    }

    private String shortStatus(Player p, Kit kit) {
        FileConfiguration c = cfg();
        KitManager km = plugin.kits();
        if (!km.hasAccess(p, kit)) return c.getString("menu.short-status.locked", "&cLocked");
        long rem = km.remaining(p, kit);
        if (rem == -1) return c.getString("menu.short-status.claimed", "&cClaimed");
        if (rem > 0) {
            return c.getString("menu.short-status.cooldown", "&e{time}")
                    .replace("{time}", KitManager.formatTime(rem));
        }
        return c.getString("menu.short-status.ready", "&aReady");
    }

    private Component statusLine(Player p, Kit kit) {
        FileConfiguration c = cfg();
        KitManager km = plugin.kits();
        if (!km.hasAccess(p, kit)) return plugin.mm(c.getString("status.locked", "Locked"));
        long rem = km.remaining(p, kit);
        if (rem == -1) return plugin.mm(c.getString("status.claimed", "Claimed"));
        if (rem > 0) {
            return plugin.mm(c.getString("status.cooldown", "Cooldown: {time}")
                    .replace("{time}", KitManager.formatTime(rem)));
        }
        return plugin.mm(c.getString("status.ready", "Ready"));
    }

    // ------------------------------------------------------------ /kit edit

    public void openEdit(Player player, Kit kit) {
        stopLive(player);
        String id = kit.id();
        Kit k = plugin.kits().resolve(player, id);
        if (k == null) return;
        boolean draft = plugin.kits().isDraft(player, id);

        String claim = k.oneTime() ? "Sekali doang"
                : (k.cooldown() > 0 ? "Berwaktu (" + KitManager.formatTime(k.cooldown() * 1000) + ")" : "Berwaktu (tanpa cooldown)");
        List<Component> lines = List.of(
                plugin.mm("<gray>Kategori: <white>" + (k.category() == Kit.Category.PREMIUM ? "Premium" : "Basic")),
                plugin.mm("<gray>Permission: <white>" + (k.permissionRequired() ? "ON (" + k.node() + ")" : "OFF")),
                plugin.mm("<gray>Claim: <white>" + claim),
                plugin.mm("<gray>Jumlah item: <white>" + k.items().size()),
                plugin.mm(draft ? "<yellow>Belum disimpan. Klik Save Kit biar kitnya muncul." : ""));

        List<ActionButton> buttons = new ArrayList<>();
        if (draft) {
            buttons.add(button("&a&lSave Kit", Component.text("Simpan kit biar muncul di daftar"), act(p -> {
                if (!p.hasPermission("dialogkits.admin")) return;
                Kit saved = plugin.kits().commitDraft(p);
                if (saved != null) p.sendMessage(plugin.msg("created", "kit", saved.id()));
            })));
        }
        buttons.add(button("&aEdit Settings", null, act(p -> {
                    if (!p.hasPermission("dialogkits.admin")) return;
                    Kit cur = plugin.kits().resolve(p, id);
                    if (cur != null) openEditForm(p, cur);
                })));
        buttons.add(button("&bEdit Items (Chest)", Component.text("Buka chest buat atur item kit"),
                act(p -> {
                    if (!p.hasPermission("dialogkits.admin")) return;
                    Kit cur = plugin.kits().resolve(p, id);
                    if (cur != null) Bukkit.getScheduler().runTask(plugin, () -> openItemEditor(p, cur));
                })));

        ActionButton exit = draft
                ? button("&cCancel", Component.text("Batalin, kit gak jadi dibuat"), act(p -> {
                    plugin.kits().clearDraft(p.getUniqueId());
                    p.sendMessage(plugin.msg("draft-cancelled", "kit", id));
                }))
                : closeButton();

        Dialog dialog = Dialog.create(b -> b.empty()
                .base(DialogBase.builder(plugin.mm("<gold><bold>" + (draft ? "Buat: " : "Edit: ") + "</bold><white>" + id))
                        .canCloseWithEscape(true)
                        .body(List.of(DialogBody.plainMessage(
                                Component.join(JoinConfiguration.newlines(), lines))))
                        .build())
                .type(DialogType.multiAction(buttons, exit, 1)));
        player.showDialog(dialog);
    }

    private void openEditForm(Player player, Kit kit) {
        String id = kit.id();
        String cooldownText = kit.cooldown() <= 0 ? "0" : KitManager.formatTime(kit.cooldown() * 1000);

        List<DialogInput> inputs = new ArrayList<>();
        inputs.add(DialogInput.text("label", Component.text("Nama + icon (contoh: {diamond} &6VIP)"))
                .initial(kit.label()).width(300).maxLength(200).build());
        inputs.add(DialogInput.text("description", Component.text("Deskripsi"))
                .initial(kit.description()).width(300).maxLength(200).build());
        inputs.add(DialogInput.singleOption("category", Component.text("Kategori"), List.of(
                SingleOptionDialogInput.OptionEntry.create("basic", Component.text("Basic Kits"),
                        kit.category() == Kit.Category.BASIC),
                SingleOptionDialogInput.OptionEntry.create("premium", Component.text("Premium Kits"),
                        kit.category() == Kit.Category.PREMIUM))).build());
        inputs.add(DialogInput.bool("perm", Component.text("Pakai permission (" + kit.node() + ")"))
                .initial(kit.permissionRequired()).build());
        inputs.add(DialogInput.singleOption("mode", Component.text("Claim"), List.of(
                SingleOptionDialogInput.OptionEntry.create("once", Component.text("Sekali doang"), kit.oneTime()),
                SingleOptionDialogInput.OptionEntry.create("timed", Component.text("Berwaktu (cooldown)"), !kit.oneTime())))
                .build());
        inputs.add(DialogInput.text("cooldown", Component.text("Waktu cooldown (1d 2h 30m / 90s / 3600)"))
                .initial(cooldownText).width(300).maxLength(40).build());

        ActionButton save = ActionButton.builder(plugin.mm("<green>Save"))
                .width(150)
                .action(actView((p, view) -> {
                    if (!p.hasPermission("dialogkits.admin")) return;
                    Kit cur = plugin.kits().resolve(p, id);
                    if (cur == null) return;

                    long cd = KitManager.parseSeconds(view.getText("cooldown"));
                    if (cd < 0) {
                        p.sendMessage(plugin.msg("invalid-time"));
                        openEditForm(p, cur);
                        return;
                    }
                    String label = view.getText("label");
                    String desc = view.getText("description");
                    String cat = view.getText("category");
                    String mode = view.getText("mode");
                    Boolean perm = view.getBoolean("perm");

                    plugin.kits().persist(p, new Kit(id,
                            label == null || label.isBlank() ? cur.label() : label,
                            desc == null ? "" : desc,
                            Kit.Category.from(cat),
                            Boolean.TRUE.equals(perm),
                            cur.permission(),
                            "once".equalsIgnoreCase(mode),
                            cd,
                            cur.commands(),
                            cur.items()));
                    p.sendMessage(plugin.msg("edit-saved", "kit", id));
                    Kit fresh = plugin.kits().resolve(p, id);
                    if (fresh != null) openEdit(p, fresh);
                }))
                .build();

        ActionButton cancel = ActionButton.builder(plugin.mm("<red>Cancel"))
                .width(150)
                .action(act(p -> {
                    Kit cur = plugin.kits().resolve(p, id);
                    if (cur != null) openEdit(p, cur);
                }))
                .build();

        Dialog dialog = Dialog.create(b -> b.empty()
                .base(DialogBase.builder(plugin.mm("<gold><bold>Settings: </bold><white>" + id))
                        .canCloseWithEscape(true)
                        .inputs(inputs)
                        .build())
                .type(DialogType.confirmation(save, cancel)));
        player.showDialog(dialog);
    }

    // ------------------------------------------------------------ editor item (double chest)

    public void openItemEditor(Player player, Kit kit) {
        FileConfiguration c = cfg();
        EditorHolder h = new EditorHolder(kit.id());
        Inventory inv = Bukkit.createInventory(h, 54,
                plugin.mm(c.getString("editor.title", "Items: {kit}").replace("{kit}", kit.id())));
        h.inventory = inv;

        List<ItemStack> items = kit.items();
        for (int i = 0; i < EditorHolder.ITEM_SLOTS && i < items.size(); i++) {
            ItemStack it = items.get(i);
            h.original[i] = it.clone();
            inv.setItem(i, it.clone());
        }

        ItemStack filler = control("editor.filler-item", "BLACK_STAINED_GLASS_PANE", " ");
        for (int i = EditorHolder.ITEM_SLOTS; i < 54; i++) inv.setItem(i, filler);
        inv.setItem(EditorHolder.UNDO_SLOT, control("editor.undo-item", "YELLOW_CONCRETE",
                c.getString("editor.undo-name", "&e&lUNDO")));
        inv.setItem(EditorHolder.SAVE_SLOT, control("editor.save-item", "LIME_CONCRETE",
                c.getString("editor.save-name", "&a&lSAVE")));
        player.openInventory(inv);
    }

    private ItemStack control(String key, String def, String name) {
        Material m = Material.matchMaterial(cfg().getString(key, def));
        if (m == null || !m.isItem()) m = Material.matchMaterial(def);
        ItemStack it = new ItemStack(m);
        it.editMeta(meta -> meta.displayName(plugin.mm(name).decoration(TextDecoration.ITALIC, false)));
        return it;
    }
}
