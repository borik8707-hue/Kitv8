package com.dudung.dialogkits;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public final class KitCommand implements TabExecutor {

    private final DialogKits plugin;

    public KitCommand(DialogKits plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        // /kit -> menu utama
        if (args.length == 0) {
            if (sender instanceof Player p) plugin.menu().openMain(p);
            else sender.sendMessage(plugin.msg("players-only"));
            return true;
        }

        String sub = args[0].toLowerCase();
        boolean admin = sender.hasPermission("dialogkits.admin");

        switch (sub) {
            case "basic", "premium" -> {
                if (!(sender instanceof Player p)) { sender.sendMessage(plugin.msg("players-only")); return true; }
                plugin.menu().openCategory(p, sub.equals("basic") ? Kit.Category.BASIC : Kit.Category.PREMIUM);
                return true;
            }
            case "icontest" -> {
                if (!admin) return noPerm(sender);
                String[][] tests = {
                        {"items", "item/iron_sword"}, {"blocks", "item/iron_sword"},
                        {"items", "item/apple"}, {"blocks", "item/apple"},
                        {"blocks", "block/oak_log"}, {"blocks", "block/crafting_table_front"}};
                int n = 1;
                for (String[] t : tests) {
                    sender.sendMessage(plugin.mm("&7" + n++ + ") &f" + t[0] + " &8| &f" + t[1]
                            + " &8-> &r<sprite:" + t[0] + ":" + t[1] + ">"));
                }
                sender.sendMessage(plugin.mm("&7Yang tampil gambar = atlas itu bener. Pink-hitam = salah."));
                return true;
            }
            case "reload" -> {
                if (!admin) return noPerm(sender);
                plugin.reloadAll();
                sender.sendMessage(plugin.msg("reloaded"));
                return true;
            }
            case "create" -> {
                if (!admin) return noPerm(sender);
                if (!(sender instanceof Player p)) { sender.sendMessage(plugin.msg("players-only")); return true; }
                if (args.length < 3 || !(args[1].equalsIgnoreCase("basic") || args[1].equalsIgnoreCase("premium"))) {
                    p.sendMessage(plugin.mm("&c/kit create <basic|premium> <nama>"));
                    return true;
                }
                String name = args[2];
                if (KitManager.RESERVED.contains(name.toLowerCase())) { p.sendMessage(plugin.msg("reserved-name")); return true; }
                if (!KitManager.validId(name)) { p.sendMessage(plugin.msg("invalid-name")); return true; }
                if (plugin.kits().get(name) != null) { p.sendMessage(plugin.msg("exists", "kit", name.toLowerCase())); return true; }
                Kit draft = plugin.kits().newDraft(p, Kit.Category.from(args[1]), name);
                p.sendMessage(plugin.msg("draft-started", "kit", draft.id()));
                plugin.menu().openEdit(p, draft);
                return true;
            }
            case "edit" -> {
                if (!admin) return noPerm(sender);
                if (!(sender instanceof Player p)) { sender.sendMessage(plugin.msg("players-only")); return true; }
                if (args.length < 2) { p.sendMessage(plugin.mm("&c/kit edit <nama>")); return true; }
                Kit kit = plugin.kits().get(args[1]);
                if (kit == null) { p.sendMessage(plugin.msg("not-found")); return true; }
                plugin.menu().openEdit(p, kit);
                return true;
            }
            case "delete" -> {
                if (!admin) return noPerm(sender);
                if (args.length < 2) { sender.sendMessage(plugin.mm("&c/kit delete <nama>")); return true; }
                sender.sendMessage(plugin.kits().delete(args[1])
                        ? plugin.msg("deleted", "kit", args[1])
                        : plugin.msg("not-found"));
                return true;
            }
            case "give" -> {
                if (!admin) return noPerm(sender);
                if (args.length < 3) { sender.sendMessage(plugin.mm("&c/kit give <kit> <player>")); return true; }
                Kit kit = plugin.kits().get(args[1]);
                Player target = Bukkit.getPlayerExact(args[2]);
                if (kit == null) { sender.sendMessage(plugin.msg("not-found")); return true; }
                if (target == null) { sender.sendMessage(plugin.msg("player-not-found")); return true; }
                plugin.kits().claim(target, kit, true);
                sender.sendMessage(plugin.msg("gave", "kit", kit.id(), "player", target.getName()));
                return true;
            }
            default -> {
                // /kit <nama> -> claim langsung
                if (!(sender instanceof Player p)) { sender.sendMessage(plugin.msg("players-only")); return true; }
                Kit kit = plugin.kits().get(args[0]);
                if (kit == null) { p.sendMessage(plugin.msg("not-found")); return true; }
                plugin.claim(p, kit);
                return true;
            }
        }
    }

    private boolean noPerm(CommandSender s) {
        s.sendMessage(plugin.msg("no-permission"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        List<String> out = new ArrayList<>();
        boolean admin = sender.hasPermission("dialogkits.admin");
        if (args.length == 1) {
            String a = args[0].toLowerCase();
            plugin.kits().all().forEach(k -> { if (k.id().startsWith(a)) out.add(k.id()); });
            for (String s : List.of("basic", "premium")) if (s.startsWith(a)) out.add(s);
            if (admin) for (String s : List.of("create", "delete", "edit", "give", "reload", "icontest")) if (s.startsWith(a)) out.add(s);
        } else if (args.length == 2 && admin && args[0].equalsIgnoreCase("create")) {
            String a = args[1].toLowerCase();
            for (String s : List.of("basic", "premium")) if (s.startsWith(a)) out.add(s);
        } else if (args.length == 2 && admin) {
            String a = args[1].toLowerCase();
            String s0 = args[0].toLowerCase();
            if (s0.equals("delete") || s0.equals("give") || s0.equals("edit")) {
                plugin.kits().all().forEach(k -> { if (k.id().startsWith(a)) out.add(k.id()); });
            }
        } else if (args.length == 3 && admin && args[0].equalsIgnoreCase("give")) {
            Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        }
        return out;
    }
}
