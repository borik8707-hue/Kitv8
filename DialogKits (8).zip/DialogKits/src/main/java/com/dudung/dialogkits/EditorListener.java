package com.dudung.dialogkits;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public final class EditorListener implements Listener {

    private final DialogKits plugin;

    public EditorListener(DialogKits plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof EditorHolder h)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;

        int raw = e.getRawSlot();

        // baris tombol
        if (raw >= EditorHolder.ITEM_SLOTS && raw < 54) {
            e.setCancelled(true);
            if (raw == EditorHolder.SAVE_SLOT) save(p, h, top);
            else if (raw == EditorHolder.UNDO_SLOT) undo(h, top);
            return;
        }

        if (e.getClick() == ClickType.DOUBLE_CLICK) {
            e.setCancelled(true);
            return;
        }

        // shift-click dari inventory player -> masukin manual ke slot item (hindari baris tombol)
        if (e.isShiftClick() && raw >= 54) {
            e.setCancelled(true);
            ItemStack cur = e.getCurrentItem();
            if (cur == null || cur.getType().isAir()) return;
            ItemStack rest = insert(top, cur.clone());
            e.setCurrentItem(rest);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof EditorHolder)) return;
        for (int raw : e.getRawSlots()) {
            if (raw >= EditorHolder.ITEM_SLOTS && raw < 54) {
                e.setCancelled(true);
                return;
            }
        }
    }

    private void save(Player p, EditorHolder h, Inventory inv) {
        if (!p.hasPermission("dialogkits.admin")) {
            Bukkit.getScheduler().runTask(plugin, () -> p.closeInventory());
            return;
        }
        Kit kit = plugin.kits().resolve(p, h.kitId);
        if (kit == null) {
            Bukkit.getScheduler().runTask(plugin, () -> p.closeInventory());
            return;
        }
        List<ItemStack> items = new ArrayList<>();
        for (int i = 0; i < EditorHolder.ITEM_SLOTS; i++) {
            ItemStack s = inv.getItem(i);
            if (s != null && !s.getType().isAir()) items.add(s.clone());
        }
        plugin.kits().persist(p, kit.withItems(items));
        p.sendMessage(plugin.msg("items-saved", "kit", h.kitId, "count", String.valueOf(items.size())));

        Bukkit.getScheduler().runTask(plugin, () -> {
            p.closeInventory();
            Kit fresh = plugin.kits().resolve(p, h.kitId);
            if (fresh != null) plugin.menu().openEdit(p, fresh);
        });
    }

    private void undo(EditorHolder h, Inventory inv) {
        for (int i = 0; i < EditorHolder.ITEM_SLOTS; i++) {
            ItemStack o = h.original[i];
            inv.setItem(i, o == null ? null : o.clone());
        }
    }

    /** Masukin item ke slot 0-44. Return sisa (null kalau habis). */
    private ItemStack insert(Inventory inv, ItemStack stack) {
        int max = stack.getMaxStackSize();
        for (int i = 0; i < EditorHolder.ITEM_SLOTS && stack.getAmount() > 0; i++) {
            ItemStack s = inv.getItem(i);
            if (s != null && s.isSimilar(stack) && s.getAmount() < max) {
                int move = Math.min(max - s.getAmount(), stack.getAmount());
                s.setAmount(s.getAmount() + move);
                inv.setItem(i, s);
                stack.setAmount(stack.getAmount() - move);
            }
        }
        for (int i = 0; i < EditorHolder.ITEM_SLOTS && stack.getAmount() > 0; i++) {
            ItemStack s = inv.getItem(i);
            if (s == null || s.getType().isAir()) {
                inv.setItem(i, stack.clone());
                stack.setAmount(0);
            }
        }
        return stack.getAmount() > 0 ? stack : null;
    }
}
