package com.dudung.dialogkits;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

/** Penanda inventory editor item (double chest). */
public final class EditorHolder implements InventoryHolder {

    public static final int ITEM_SLOTS = 45; // slot 0-44 buat item, 45-53 tombol
    public static final int UNDO_SLOT = 47;
    public static final int SAVE_SLOT = 51;

    public final String kitId;
    public final ItemStack[] original = new ItemStack[ITEM_SLOTS];
    public Inventory inventory;

    public EditorHolder(String kitId) {
        this.kitId = kitId;
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }
}
