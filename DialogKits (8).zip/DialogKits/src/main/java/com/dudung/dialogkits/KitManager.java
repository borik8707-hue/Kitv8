package com.dudung.dialogkits;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class KitManager {

    public enum Result { OK, NO_PERMISSION, COOLDOWN, ONE_TIME, FULL }

    /** Nama subcommand, gak boleh jadi nama kit. */
    public static final Set<String> RESERVED =
            Set.of("create", "delete", "give", "edit", "reload", "basic", "premium", "icontest");

    private static final Pattern VALID_ID = Pattern.compile("[A-Za-z0-9_-]{1,32}");

    private final DialogKits plugin;
    private final File kitFile;
    private final File dataFile;
    private YamlConfiguration kitCfg;
    private final Map<String, Kit> kits = new LinkedHashMap<>();

    // Data cooldown disimpan di memori, disave async tiap 5 menit kalau ada perubahan.
    private final Map<UUID, Map<String, Long>> data = new ConcurrentHashMap<>();
    private volatile boolean dirty;
    private BukkitTask flushTask;

    public KitManager(DialogKits plugin) {
        this.plugin = plugin;
        this.kitFile = new File(plugin.getDataFolder(), "kits.yml");
        this.dataFile = new File(plugin.getDataFolder(), "data.yml");
    }

    // ------------------------------------------------------------ lifecycle

    public void start() {
        loadData();
        flushTask = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, this::flush, 6000L, 6000L);
    }

    public void stop() {
        if (flushTask != null) flushTask.cancel();
        flush();
    }

    private void loadData() {
        data.clear();
        if (!dataFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection root = y.getConfigurationSection("data");
        if (root == null) return;
        long now = System.currentTimeMillis();
        for (String u : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(u);
            if (s == null) continue;
            UUID uuid;
            try { uuid = UUID.fromString(u); } catch (IllegalArgumentException e) { continue; }
            Map<String, Long> m = new ConcurrentHashMap<>();
            for (String k : s.getKeys(false)) {
                long v = s.getLong(k);
                if (v == -1 || v > now) m.put(k, v); // cooldown yang udah lewat dibuang
            }
            if (!m.isEmpty()) data.put(uuid, m);
        }
    }

    public synchronized void flush() {
        if (!dirty) return;
        dirty = false;
        YamlConfiguration y = new YamlConfiguration();
        data.forEach((u, m) -> m.forEach((k, v) -> y.set("data." + u + "." + k, v)));
        try {
            y.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal save data.yml: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------ kits

    public void load() {
        if (!kitFile.exists()) plugin.saveResource("kits.yml", false);
        kitCfg = YamlConfiguration.loadConfiguration(kitFile);
        kits.clear();

        ConfigurationSection root = kitCfg.getConfigurationSection("kits");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection k = root.getConfigurationSection(id);
            if (k == null) continue;

            List<ItemStack> items = new ArrayList<>();
            for (Object o : k.getList("items", List.of())) {
                if (o instanceof ItemStack i) items.add(i);
            }
            for (String s : k.getStringList("simple-items")) {
                String[] parts = s.split(":");
                Material m = Material.matchMaterial(parts[0]);
                if (m == null) {
                    plugin.getLogger().warning("Material gak valid di kit " + id + ": " + s);
                    continue;
                }
                int amount = 1;
                if (parts.length > 1) {
                    try { amount = Integer.parseInt(parts[1]); } catch (NumberFormatException ignored) { }
                }
                items.add(new ItemStack(m, amount));
            }

            String perm = k.getString("permission", "");
            boolean permReq = k.contains("permission-required")
                    ? k.getBoolean("permission-required") : !perm.isEmpty();
            boolean once = k.contains("claim-mode")
                    ? "once".equalsIgnoreCase(k.getString("claim-mode")) : k.getBoolean("one-time", false);

            String key = id.toLowerCase();
            kits.put(key, new Kit(
                    key,
                    k.getString("label", "&f" + id),
                    k.getString("description", ""),
                    Kit.Category.from(k.getString("category", "basic")),
                    permReq, perm, once,
                    k.getLong("cooldown", 0),
                    k.getStringList("commands"),
                    items));
        }
    }

    public Collection<Kit> all() { return kits.values(); }

    public List<Kit> in(Kit.Category cat) {
        List<Kit> out = new ArrayList<>();
        for (Kit k : kits.values()) if (k.category() == cat) out.add(k);
        return out;
    }

    public Kit get(String id) { return id == null ? null : kits.get(id.toLowerCase()); }

    public static boolean validId(String id) { return VALID_ID.matcher(id).matches(); }

    // Draft = kit yang lagi dibikin lewat /kit create, belum masuk kits.yml sampai klik Save Kit.
    private final Map<UUID, Kit> drafts = new HashMap<>();

    public Kit newDraft(Player p, Kit.Category cat, String id) {
        var c = plugin.getConfig();
        boolean permReq = c.getBoolean(cat == Kit.Category.PREMIUM
                ? "defaults.permission-required-premium" : "defaults.permission-required-basic",
                cat == Kit.Category.PREMIUM);
        Kit kit = new Kit(id.toLowerCase(), "&f" + id, "", cat, permReq, "",
                "once".equalsIgnoreCase(c.getString("defaults.claim-mode", "timed")),
                c.getLong("defaults.cooldown", 86400), List.of(), List.of());
        drafts.put(p.getUniqueId(), kit);
        return kit;
    }

    public boolean isDraft(Player p, String id) {
        Kit d = drafts.get(p.getUniqueId());
        return d != null && d.id().equalsIgnoreCase(id);
    }

    /** Kit yang lagi diedit: draft kalau ada, kalau gak ya kit asli. */
    public Kit resolve(Player p, String id) {
        return isDraft(p, id) ? drafts.get(p.getUniqueId()) : get(id);
    }

    /** Simpan perubahan: ke draft (memori) atau langsung ke kits.yml. */
    public void persist(Player p, Kit kit) {
        if (isDraft(p, kit.id())) drafts.put(p.getUniqueId(), kit);
        else save(kit);
    }

    /** Draft -> kits.yml. Baru setelah ini kit muncul di Basic/Premium. */
    public Kit commitDraft(Player p) {
        Kit d = drafts.remove(p.getUniqueId());
        if (d == null) return null;
        save(d);
        return get(d.id());
    }

    public Kit clearDraft(UUID id) {
        return drafts.remove(id);
    }

    /** Bikin kit kosong baru (item diisi lewat editor chest). */
    public Kit create(Kit.Category cat, String id) {
        var c = plugin.getConfig();
        boolean permReq = c.getBoolean(cat == Kit.Category.PREMIUM
                ? "defaults.permission-required-premium" : "defaults.permission-required-basic",
                cat == Kit.Category.PREMIUM);
        Kit kit = new Kit(id.toLowerCase(), "&f" + id, "", cat, permReq, "",
                "once".equalsIgnoreCase(c.getString("defaults.claim-mode", "timed")),
                c.getLong("defaults.cooldown", 86400), List.of(), List.of());
        save(kit);
        return get(kit.id());
    }

    /** Simpan satu kit ke kits.yml lalu reload. */
    public void save(Kit kit) {
        String path = "kits." + kit.id();
        kitCfg.set(path + ".label", kit.label());
        kitCfg.set(path + ".description", kit.description());
        kitCfg.set(path + ".category", kit.category().key());
        kitCfg.set(path + ".permission-required", kit.permissionRequired());
        kitCfg.set(path + ".permission", kit.permission() == null || kit.permission().isBlank() ? null : kit.permission());
        kitCfg.set(path + ".claim-mode", kit.oneTime() ? "once" : "timed");
        kitCfg.set(path + ".cooldown", kit.cooldown());
        kitCfg.set(path + ".commands", kit.commands());
        kitCfg.set(path + ".one-time", null);
        kitCfg.set(path + ".simple-items", null);
        kitCfg.set(path + ".items", new ArrayList<>(kit.items()));
        saveKits();
        load();
    }

    public boolean delete(String id) {
        String path = "kits." + id.toLowerCase();
        if (kitCfg.getConfigurationSection(path) == null) return false;
        kitCfg.set(path, null);
        saveKits();
        load();
        return true;
    }

    private void saveKits() {
        try { kitCfg.save(kitFile); } catch (IOException e) { plugin.getLogger().warning("Gagal save kits.yml: " + e.getMessage()); }
    }

    // ------------------------------------------------------------ claim

    public boolean hasAccess(Player p, Kit kit) {
        return !kit.permissionRequired() || p.hasPermission(kit.node());
    }

    /** 0 = siap, -1 = sekali pakai udah diambil, >0 = sisa millis. */
    public long remaining(Player p, Kit kit) {
        if (p.hasPermission("dialogkits.bypass")) return 0;
        Map<String, Long> m = data.get(p.getUniqueId());
        Long v = m == null ? null : m.get(kit.id());
        if (v == null) return 0;
        if (v == -1) return -1;
        return Math.max(0, v - System.currentTimeMillis());
    }

    public Result claim(Player p, Kit kit, boolean force) {
        if (!force) {
            if (!hasAccess(p, kit)) return Result.NO_PERMISSION;
            long rem = remaining(p, kit);
            if (rem == -1) return Result.ONE_TIME;
            if (rem > 0) return Result.COOLDOWN;
            if ("deny".equalsIgnoreCase(plugin.getConfig().getString("claim.when-inventory-full", "drop"))
                    && freeSlots(p) < kit.items().size()) return Result.FULL;
        }
        give(p, kit);
        if (!force && !p.hasPermission("dialogkits.bypass")) {
            Long next = null;
            if (kit.oneTime()) next = -1L;
            else if (kit.cooldown() > 0) next = System.currentTimeMillis() + kit.cooldown() * 1000L;
            if (next != null) {
                data.computeIfAbsent(p.getUniqueId(), u -> new ConcurrentHashMap<>()).put(kit.id(), next);
                dirty = true;
            }
        }
        return Result.OK;
    }

    private int freeSlots(Player p) {
        int n = 0;
        for (ItemStack i : p.getInventory().getStorageContents()) {
            if (i == null || i.getType().isAir()) n++;
        }
        return n;
    }

    private void give(Player p, Kit kit) {
        PlayerInventory inv = p.getInventory();
        boolean equip = plugin.getConfig().getBoolean("claim.auto-equip-armor", true);
        boolean dropped = false;
        for (ItemStack item : kit.items()) {
            ItemStack it = item.clone();
            if (equip && equipArmor(inv, it)) continue;
            for (ItemStack rest : inv.addItem(it).values()) {
                p.getWorld().dropItemNaturally(p.getLocation(), rest);
                dropped = true;
            }
        }
        if (dropped) p.sendMessage(plugin.msg("inventory-full"));
    }

    private boolean equipArmor(PlayerInventory inv, ItemStack it) {
        String n = it.getType().name();
        EquipmentSlot slot;
        if (n.endsWith("_HELMET")) slot = EquipmentSlot.HEAD;
        else if (n.endsWith("_CHESTPLATE") || n.equals("ELYTRA")) slot = EquipmentSlot.CHEST;
        else if (n.endsWith("_LEGGINGS")) slot = EquipmentSlot.LEGS;
        else if (n.endsWith("_BOOTS")) slot = EquipmentSlot.FEET;
        else return false;

        ItemStack cur = inv.getItem(slot);
        if (cur != null && !cur.getType().isAir()) return false;
        inv.setItem(slot, it);
        return true;
    }

    // ------------------------------------------------------------ util waktu

    public static String formatTime(long millis) {
        long s = Math.max(1, millis / 1000);
        long d = s / 86400, h = (s % 86400) / 3600, m = (s % 3600) / 60, sec = s % 60;
        StringBuilder sb = new StringBuilder();
        if (d > 0) sb.append(d).append("d ");
        if (h > 0) sb.append(h).append("h ");
        if (m > 0) sb.append(m).append("m ");
        if (sec > 0 && d == 0) sb.append(sec).append("s");
        return sb.toString().trim();
    }

    private static final Pattern FULL = Pattern.compile("(\\d+\\s*[dhms]?\\s*)+");
    private static final Pattern PART = Pattern.compile("(\\d+)\\s*([dhms]?)");

    /** "1d 2h 30m", "90s", "3600" -> detik. -1 kalau formatnya salah. */
    public static long parseSeconds(String in) {
        if (in == null) return -1;
        String s = in.trim().toLowerCase();
        if (!FULL.matcher(s).matches()) return -1;
        Matcher m = PART.matcher(s);
        long total = 0;
        while (m.find()) {
            long n = Long.parseLong(m.group(1));
            total += switch (m.group(2)) {
                case "d" -> n * 86400;
                case "h" -> n * 3600;
                case "m" -> n * 60;
                default -> n;
            };
        }
        return total;
    }
}
